Paul Kotys, pjk151
Philip Okoh, pco23
Operating Systems CS416
Monday, December 13, 2021

FINAL REPORT FOR PROJECT 4 
IMPLEMENTATION OF TYPE FILE SYSTEM (TFS)
TESTED ON cd.cs.rutgers.edu

-----------------------------------------------------------
All parts of the file system were implemented successfully.
-----------------------------------------------------------

Final report is attached as a pdf
Use standard makefile (no changes from one given)
The code is well documented, does not have any memory leaks, and perfectly sets the bitmaps. 
The code passed all the benchmarks!
